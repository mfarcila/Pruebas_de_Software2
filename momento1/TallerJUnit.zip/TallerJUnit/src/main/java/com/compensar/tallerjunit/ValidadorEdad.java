
package com.compensar.tallerjunit;

public class ValidadorEdad {
   public boolean esMayorDeEdad(int edad) {
        return edad >= 18;
    } 
}
