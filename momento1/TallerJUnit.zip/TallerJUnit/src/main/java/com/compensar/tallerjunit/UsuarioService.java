
package com.compensar.tallerjunit;
import java.util.List;

public class UsuarioService {
    public Usuario buscarPorCorreo(List<Usuario> usuarios, String correo) {

        for (Usuario u : usuarios) {

            if (u.getCorreo().equalsIgnoreCase(correo)) {

                return u;

            }

        }

        return null;

    }
 
}
