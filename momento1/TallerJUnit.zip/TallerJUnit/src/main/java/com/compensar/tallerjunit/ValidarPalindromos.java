
package com.compensar.tallerjunit;

public class ValidarPalindromos {
  public boolean esPalindromo(String texto) {
        if (texto == null) return false;
        String limpio = texto.replaceAll("\\s+", "").toLowerCase();
        return new StringBuilder(limpio).reverse().toString().equals(limpio);
    }
  }  

