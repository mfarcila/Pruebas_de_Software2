
package com.compensar.tallerjunit;


public class ValidadorContraseña {
    public boolean esFuerte(String contrasena) {
        if (contrasena == null) return false;
        return contrasena.length() >= 8 && contrasena.matches(".*\\d.*");
    }
}
