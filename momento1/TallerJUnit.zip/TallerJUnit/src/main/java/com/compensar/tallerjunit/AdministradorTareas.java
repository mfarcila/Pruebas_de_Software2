
package com.compensar.tallerjunit;

import java.util.ArrayList;
import java.util.List;

public class AdministradorTareas {
    private List<String> tareas;
 
    public void agregarTarea(String tarea) {
        if (tareas == null) {
            tareas = new ArrayList<>();
        }
        tareas.add(tarea);
    }
 
    public List<String> obtenerTareas() {
        return tareas;
    }
}
