
package com.compensar.tallerjunit;

public class ProcesadorNombreUsuario {
     public String obtenerNombreUsuario(String usuario) {
        if (usuario == null) {
            return null;
        }
        if (usuario.equalsIgnoreCase("admin")) {
            return null;
        }
        return usuario;
    }
}
