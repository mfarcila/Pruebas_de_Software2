
package com.compensar.tallerjunit;


public class ComparadorCadenas {
    public String concatenar(String str1, String str2) {
        return str1.concat(str2);
    }
}
