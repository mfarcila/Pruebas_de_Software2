
package com.compensar.tallerjunit;


public class TallerJUnit {

    
    public static void main(String[] args) {
                System.out.println("Proyecto Taller JUnit listo");

    }
    
}
