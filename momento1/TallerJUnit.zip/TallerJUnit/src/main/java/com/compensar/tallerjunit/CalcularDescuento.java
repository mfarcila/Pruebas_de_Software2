
package com.compensar.tallerjunit;

public class CalcularDescuento {
     public double aplicarDescuento(double precio, double porcentaje) {
        if (precio < 0 || porcentaje < 0 || porcentaje > 100) {
            throw new IllegalArgumentException("Valores inválidos");
        }
        return precio - (precio * (porcentaje / 100));
    }
}
