
package com.compensar.tallerjunit;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;


public class ValidadorEdadTest {
    
 
    @Test
    void mayorQue18() {
        ValidadorEdad validador = new ValidadorEdad();
        assertTrue(validador.esMayorDeEdad(25)); 
    }

    @Test
    void menorQue18() {
        ValidadorEdad validador = new ValidadorEdad();
        assertFalse(validador.esMayorDeEdad(17)); 
    }

    @Test
    void justo18() {
        ValidadorEdad validador = new ValidadorEdad();
        assertTrue(validador.esMayorDeEdad(18)); 
    }
}
    

