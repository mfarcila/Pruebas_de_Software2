
package com.compensar.tallerjunit;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ValidarPalindromosTest {
    @Test
    public void testEsPalindromo() {
        ValidarPalindromos p = new ValidarPalindromos();
        assertTrue(p.esPalindromo("Anita lava la tina"));
    }
 
    @Test
    public void testNoEsPalindromo() {
        ValidarPalindromos p = new ValidarPalindromos();
        assertFalse(p.esPalindromo("Filokallianthropía"));
    }
 
    @Test
    public void testNullDevuelveFalse() {
        ValidarPalindromos p = new ValidarPalindromos();
        assertFalse(p.esPalindromo(null));
    }
    
}
