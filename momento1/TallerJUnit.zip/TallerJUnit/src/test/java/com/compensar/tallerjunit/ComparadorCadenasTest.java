
package com.compensar.tallerjunit;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ComparadorCadenasTest {
    
   
    @Test
    void concatenarCorrecto() {
        ComparadorCadenas comparador = new ComparadorCadenas ();
        assertEquals("JUnit5", comparador.concatenar("JUnit", "5"));
    }

    @Test
    void concatenarNoEsIgual() {
        ComparadorCadenas  comparador = new ComparadorCadenas ();
        assertNotEquals("hola mundo ", comparador.concatenar("hola", "mundo"));
    }
    
}
