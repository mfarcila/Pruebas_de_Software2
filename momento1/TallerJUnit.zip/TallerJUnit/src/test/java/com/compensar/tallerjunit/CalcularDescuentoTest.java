
package com.compensar.tallerjunit;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class CalcularDescuentoTest {
    
    @Test
    void descuentoValido() {
        CalcularDescuento Calcular = new CalcularDescuento();
        assertEquals(90.0, Calcular.aplicarDescuento(100.0, 10.0), 0.01);
    }

    @Test
    void sinDescuento() {
        CalcularDescuento Calcular = new CalcularDescuento();
        assertEquals(100.0, Calcular.aplicarDescuento(100.0, 0.0), 0.01);
    }

    @Test
    void descuentoTotal() {
        CalcularDescuento Calcular = new CalcularDescuento();
        assertEquals(0.0, Calcular.aplicarDescuento(100.0, 100.0), 0.01);
    }

    @Test
    void porcentajeInvalidoMayor100() {
        CalcularDescuento Calcular = new CalcularDescuento();
        assertThrows(IllegalArgumentException.class, () -> {
            Calcular.aplicarDescuento(100.0, 120.0);
        });
    }
    
}
