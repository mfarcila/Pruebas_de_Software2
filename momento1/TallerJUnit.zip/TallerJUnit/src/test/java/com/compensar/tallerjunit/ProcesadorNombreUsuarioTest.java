
package com.compensar.tallerjunit;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;


public class ProcesadorNombreUsuarioTest {
    
        @Test
    void usuarioAdminDevuelveNull() {
        ProcesadorNombreUsuario procesador = new ProcesadorNombreUsuario();
        assertNull(procesador.obtenerNombreUsuario("admin"));
    }

    @Test
    void usuarioNormalDevuelveNombre() {
        ProcesadorNombreUsuario procesador = new ProcesadorNombreUsuario();
        assertEquals("maria", procesador.obtenerNombreUsuario("maria"));
    }

    @Test
    void usuarioNuloDevuelveNull() {
        ProcesadorNombreUsuario procesador = new ProcesadorNombreUsuario();
        assertNull(procesador.obtenerNombreUsuario(null));
    }

    
}
