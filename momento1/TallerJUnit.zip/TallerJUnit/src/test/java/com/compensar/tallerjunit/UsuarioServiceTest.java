
package com.compensar.tallerjunit;
import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;


public class UsuarioServiceTest {
   @Test
    public void testEncontrarUsuario() {
        List<Usuario> usuarios = Arrays.asList(
                new Usuario("John", "john@mail.com"),
                new Usuario("Ana", "ana@mail.com")
        );
        UsuarioService us = new UsuarioService();
        Usuario encontrado = us.buscarPorCorreo(usuarios, "john@mail.com");
        assertNotNull(encontrado);
        assertEquals("John", encontrado.getNombre());
    }
 
    @Test
    public void testUsuarioNoExiste() {
        List<Usuario> usuarios = Arrays.asList(
                new Usuario("John", "john@mail.com"),
                new Usuario("Ana", "ana@mail.com")
        );
        UsuarioService us = new UsuarioService();
        assertNull(us.buscarPorCorreo(usuarios, "pepe@mail.com"));
    }
   
}
