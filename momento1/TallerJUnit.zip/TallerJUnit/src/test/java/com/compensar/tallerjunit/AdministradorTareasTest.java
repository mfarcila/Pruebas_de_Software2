
package com.compensar.tallerjunit;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;


public class AdministradorTareasTest {
    
  @Test
    public void testSinTareasEsNull() {
        AdministradorTareas g = new AdministradorTareas();
        assertNull(g.obtenerTareas());
    }
 
    @Test
    public void testConTareasNoEsNull() {
        AdministradorTareas g = new AdministradorTareas();
        g.agregarTarea("Estudiar JUnit");
        assertNotNull(g.obtenerTareas());
    }
    
}
