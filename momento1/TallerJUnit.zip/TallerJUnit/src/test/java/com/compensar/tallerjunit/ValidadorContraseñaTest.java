
package com.compensar.tallerjunit;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ValidadorContraseñaTest {
    
   @Test
    public void testContrasenaFuerte() {
        ValidadorContraseña v = new ValidadorContraseña();
        assertTrue(v.esFuerte("password123"));
    }
 
    @Test
    public void testContrasenaCorta() {
        ValidadorContraseña v = new ValidadorContraseña();
        assertFalse(v.esFuerte("pass1"));
    }
 
    @Test
    public void testSinNumero() {
        ValidadorContraseña v = new ValidadorContraseña();
        assertFalse(v.esFuerte("passwordlong"));
    }
}
