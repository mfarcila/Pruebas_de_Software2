
package com.compensar.tallerjunit;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class FactorialTest {
    
       @Test

    public void testFactorial5() {

        Factorial f = new Factorial();

        assertEquals(120, f.calcular(5));

    }
 
    @Test

    public void testFactorial0() {

        Factorial f = new Factorial();

        assertEquals(1, f.calcular(0));

    }
 
    @Test

    public void testFactorialNoEs121() {

        Factorial f = new Factorial();

        assertNotEquals(121, f.calcular(5));

    }
 
    
}
