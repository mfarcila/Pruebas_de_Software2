
package com.compensar.tallerjunit;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;


public class CalculadoraTest {
    
   @Test
    void sumaDosPositivos() {
        Calculadora calc = new Calculadora();
        assertEquals(7, calc.sumar(3, 4));
    }

    @Test
    void sumaConNegativos() {
        Calculadora calc = new Calculadora();
        assertEquals(-3, calc.sumar(-5, 2));
    }
    
}
